package com.example.saving_app_udemy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
